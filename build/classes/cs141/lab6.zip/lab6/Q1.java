/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab6;

/**
 *
 * @author thomas.kercheval
 */
public class Q1 {
    public static void main(String[] args) {
      int i = 0;
      int limit = 99;
      while (i < limit) {
         System.out.println("i = " + i);
         i++;
      }
    }
}

// The loop will never stop if we comment out the incrementor. 
